#ifndef _UDP_H
#define _UDP_H

#define UDP_PACKET_SIZE	1024
#define UDP_IN_PORT     4464	
#define UDP_OUT_PORT	4465


#endif

