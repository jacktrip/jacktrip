#ifndef _AUDIOCONSTS_H
#define _AUDIOCONSTS_H

#include <stdint.h>

typedef signed short INT16; /**< @brief Audio sample type. */

#endif
